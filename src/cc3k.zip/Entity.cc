#ifndef ENTITY_CC
#define ENTITY_CC
#include <memory>
#include <vector>

class Entity {
public:
    virtual ~Entity() = default;
};

#endif
